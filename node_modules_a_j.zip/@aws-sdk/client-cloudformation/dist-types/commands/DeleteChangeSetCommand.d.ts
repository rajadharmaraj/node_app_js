import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CloudFormationClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../CloudFormationClient";
import { DeleteChangeSetInput, DeleteChangeSetOutput } from "../models/models_0";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link DeleteChangeSetCommand}.
 */
export interface DeleteChangeSetCommandInput extends DeleteChangeSetInput {
}
/**
 * @public
 *
 * The output of {@link DeleteChangeSetCommand}.
 */
export interface DeleteChangeSetCommandOutput extends DeleteChangeSetOutput, __MetadataBearer {
}
declare const DeleteChangeSetCommand_base: {
    new (input: DeleteChangeSetCommandInput): import("@smithy/smithy-client").CommandImpl<DeleteChangeSetCommandInput, DeleteChangeSetCommandOutput, CloudFormationClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 * <p>Deletes the specified change set. Deleting change sets ensures that no one executes the wrong change set.</p>
 *          <p>If the call successfully completes, CloudFormation successfully deleted the change set.</p>
 *          <p>If <code>IncludeNestedStacks</code> specifies <code>True</code> during the creation of the nested change set,
 *    then <code>DeleteChangeSet</code> will delete all change sets that belong to the stacks hierarchy and will also
 *    delete all change sets for nested stacks with the status of <code>REVIEW_IN_PROGRESS</code>.</p>
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { CloudFormationClient, DeleteChangeSetCommand } from "@aws-sdk/client-cloudformation"; // ES Modules import
 * // const { CloudFormationClient, DeleteChangeSetCommand } = require("@aws-sdk/client-cloudformation"); // CommonJS import
 * const client = new CloudFormationClient(config);
 * const input = { // DeleteChangeSetInput
 *   ChangeSetName: "STRING_VALUE", // required
 *   StackName: "STRING_VALUE",
 * };
 * const command = new DeleteChangeSetCommand(input);
 * const response = await client.send(command);
 * // {};
 *
 * ```
 *
 * @param DeleteChangeSetCommandInput - {@link DeleteChangeSetCommandInput}
 * @returns {@link DeleteChangeSetCommandOutput}
 * @see {@link DeleteChangeSetCommandInput} for command's `input` shape.
 * @see {@link DeleteChangeSetCommandOutput} for command's `response` shape.
 * @see {@link CloudFormationClientResolvedConfig | config} for CloudFormationClient's `config` shape.
 *
 * @throws {@link InvalidChangeSetStatusException} (client fault)
 *  <p>The specified change set can't be used to update the stack. For example, the change set status might be
 *     <code>CREATE_IN_PROGRESS</code>, or the stack status might be <code>UPDATE_IN_PROGRESS</code>.</p>
 *
 * @throws {@link CloudFormationServiceException}
 * <p>Base exception class for all service exceptions from CloudFormation service.</p>
 *
 */
export declare class DeleteChangeSetCommand extends DeleteChangeSetCommand_base {
}
