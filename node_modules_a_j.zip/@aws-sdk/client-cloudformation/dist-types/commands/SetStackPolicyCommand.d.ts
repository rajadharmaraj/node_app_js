import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CloudFormationClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../CloudFormationClient";
import { SetStackPolicyInput } from "../models/models_0";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link SetStackPolicyCommand}.
 */
export interface SetStackPolicyCommandInput extends SetStackPolicyInput {
}
/**
 * @public
 *
 * The output of {@link SetStackPolicyCommand}.
 */
export interface SetStackPolicyCommandOutput extends __MetadataBearer {
}
declare const SetStackPolicyCommand_base: {
    new (input: SetStackPolicyCommandInput): import("@smithy/smithy-client").CommandImpl<SetStackPolicyCommandInput, SetStackPolicyCommandOutput, CloudFormationClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 * <p>Sets a stack policy for a specified stack.</p>
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { CloudFormationClient, SetStackPolicyCommand } from "@aws-sdk/client-cloudformation"; // ES Modules import
 * // const { CloudFormationClient, SetStackPolicyCommand } = require("@aws-sdk/client-cloudformation"); // CommonJS import
 * const client = new CloudFormationClient(config);
 * const input = { // SetStackPolicyInput
 *   StackName: "STRING_VALUE", // required
 *   StackPolicyBody: "STRING_VALUE",
 *   StackPolicyURL: "STRING_VALUE",
 * };
 * const command = new SetStackPolicyCommand(input);
 * const response = await client.send(command);
 * // {};
 *
 * ```
 *
 * @param SetStackPolicyCommandInput - {@link SetStackPolicyCommandInput}
 * @returns {@link SetStackPolicyCommandOutput}
 * @see {@link SetStackPolicyCommandInput} for command's `input` shape.
 * @see {@link SetStackPolicyCommandOutput} for command's `response` shape.
 * @see {@link CloudFormationClientResolvedConfig | config} for CloudFormationClient's `config` shape.
 *
 * @throws {@link CloudFormationServiceException}
 * <p>Base exception class for all service exceptions from CloudFormation service.</p>
 *
 */
export declare class SetStackPolicyCommand extends SetStackPolicyCommand_base {
}
