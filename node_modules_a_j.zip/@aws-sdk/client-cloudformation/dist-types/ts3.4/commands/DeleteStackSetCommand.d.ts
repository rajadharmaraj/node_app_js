import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { DeleteStackSetInput, DeleteStackSetOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DeleteStackSetCommandInput extends DeleteStackSetInput {}
export interface DeleteStackSetCommandOutput
  extends DeleteStackSetOutput,
    __MetadataBearer {}
declare const DeleteStackSetCommand_base: {
  new (
    input: DeleteStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteStackSetCommandInput,
    DeleteStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteStackSetCommand extends DeleteStackSetCommand_base {}
