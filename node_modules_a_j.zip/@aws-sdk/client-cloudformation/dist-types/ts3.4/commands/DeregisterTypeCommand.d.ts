import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { DeregisterTypeInput, DeregisterTypeOutput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DeregisterTypeCommandInput extends DeregisterTypeInput {}
export interface DeregisterTypeCommandOutput
  extends DeregisterTypeOutput,
    __MetadataBearer {}
declare const DeregisterTypeCommand_base: {
  new (
    input: DeregisterTypeCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeregisterTypeCommandInput,
    DeregisterTypeCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeregisterTypeCommand extends DeregisterTypeCommand_base {}
