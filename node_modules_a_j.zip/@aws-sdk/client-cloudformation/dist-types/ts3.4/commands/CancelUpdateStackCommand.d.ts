import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { CancelUpdateStackInput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CancelUpdateStackCommandInput extends CancelUpdateStackInput {}
export interface CancelUpdateStackCommandOutput extends __MetadataBearer {}
declare const CancelUpdateStackCommand_base: {
  new (
    input: CancelUpdateStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CancelUpdateStackCommandInput,
    CancelUpdateStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CancelUpdateStackCommand extends CancelUpdateStackCommand_base {}
