import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackResourceInput,
  DescribeStackResourceOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackResourceCommandInput
  extends DescribeStackResourceInput {}
export interface DescribeStackResourceCommandOutput
  extends DescribeStackResourceOutput,
    __MetadataBearer {}
declare const DescribeStackResourceCommand_base: {
  new (
    input: DescribeStackResourceCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackResourceCommandInput,
    DescribeStackResourceCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackResourceCommand extends DescribeStackResourceCommand_base {}
