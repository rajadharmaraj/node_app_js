import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DetectStackResourceDriftInput,
  DetectStackResourceDriftOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DetectStackResourceDriftCommandInput
  extends DetectStackResourceDriftInput {}
export interface DetectStackResourceDriftCommandOutput
  extends DetectStackResourceDriftOutput,
    __MetadataBearer {}
declare const DetectStackResourceDriftCommand_base: {
  new (
    input: DetectStackResourceDriftCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DetectStackResourceDriftCommandInput,
    DetectStackResourceDriftCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DetectStackResourceDriftCommand extends DetectStackResourceDriftCommand_base {}
