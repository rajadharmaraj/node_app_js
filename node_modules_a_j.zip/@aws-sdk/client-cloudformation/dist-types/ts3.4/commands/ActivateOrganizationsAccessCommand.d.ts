import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ActivateOrganizationsAccessInput,
  ActivateOrganizationsAccessOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ActivateOrganizationsAccessCommandInput
  extends ActivateOrganizationsAccessInput {}
export interface ActivateOrganizationsAccessCommandOutput
  extends ActivateOrganizationsAccessOutput,
    __MetadataBearer {}
declare const ActivateOrganizationsAccessCommand_base: {
  new (
    input: ActivateOrganizationsAccessCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ActivateOrganizationsAccessCommandInput,
    ActivateOrganizationsAccessCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ActivateOrganizationsAccessCommand extends ActivateOrganizationsAccessCommand_base {}
