import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeGeneratedTemplateInput,
  DescribeGeneratedTemplateOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeGeneratedTemplateCommandInput
  extends DescribeGeneratedTemplateInput {}
export interface DescribeGeneratedTemplateCommandOutput
  extends DescribeGeneratedTemplateOutput,
    __MetadataBearer {}
declare const DescribeGeneratedTemplateCommand_base: {
  new (
    input: DescribeGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeGeneratedTemplateCommandInput,
    DescribeGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeGeneratedTemplateCommand extends DescribeGeneratedTemplateCommand_base {}
