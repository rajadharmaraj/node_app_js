import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  BatchDescribeTypeConfigurationsInput,
  BatchDescribeTypeConfigurationsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface BatchDescribeTypeConfigurationsCommandInput
  extends BatchDescribeTypeConfigurationsInput {}
export interface BatchDescribeTypeConfigurationsCommandOutput
  extends BatchDescribeTypeConfigurationsOutput,
    __MetadataBearer {}
declare const BatchDescribeTypeConfigurationsCommand_base: {
  new (
    input: BatchDescribeTypeConfigurationsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    BatchDescribeTypeConfigurationsCommandInput,
    BatchDescribeTypeConfigurationsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class BatchDescribeTypeConfigurationsCommand extends BatchDescribeTypeConfigurationsCommand_base {}
