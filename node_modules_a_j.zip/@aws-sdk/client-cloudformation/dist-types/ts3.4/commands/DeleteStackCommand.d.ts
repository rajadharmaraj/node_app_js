import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { DeleteStackInput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DeleteStackCommandInput extends DeleteStackInput {}
export interface DeleteStackCommandOutput extends __MetadataBearer {}
declare const DeleteStackCommand_base: {
  new (
    input: DeleteStackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteStackCommandInput,
    DeleteStackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteStackCommand extends DeleteStackCommand_base {}
