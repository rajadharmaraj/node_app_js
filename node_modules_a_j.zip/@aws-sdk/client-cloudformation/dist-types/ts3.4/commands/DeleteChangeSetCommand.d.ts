import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DeleteChangeSetInput,
  DeleteChangeSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DeleteChangeSetCommandInput extends DeleteChangeSetInput {}
export interface DeleteChangeSetCommandOutput
  extends DeleteChangeSetOutput,
    __MetadataBearer {}
declare const DeleteChangeSetCommand_base: {
  new (
    input: DeleteChangeSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteChangeSetCommandInput,
    DeleteChangeSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteChangeSetCommand extends DeleteChangeSetCommand_base {}
