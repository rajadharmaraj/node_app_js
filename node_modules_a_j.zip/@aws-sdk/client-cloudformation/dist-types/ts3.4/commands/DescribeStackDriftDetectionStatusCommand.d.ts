import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackDriftDetectionStatusInput,
  DescribeStackDriftDetectionStatusOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackDriftDetectionStatusCommandInput
  extends DescribeStackDriftDetectionStatusInput {}
export interface DescribeStackDriftDetectionStatusCommandOutput
  extends DescribeStackDriftDetectionStatusOutput,
    __MetadataBearer {}
declare const DescribeStackDriftDetectionStatusCommand_base: {
  new (
    input: DescribeStackDriftDetectionStatusCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackDriftDetectionStatusCommandInput,
    DescribeStackDriftDetectionStatusCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackDriftDetectionStatusCommand extends DescribeStackDriftDetectionStatusCommand_base {}
