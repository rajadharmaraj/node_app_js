import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  ContinueUpdateRollbackInput,
  ContinueUpdateRollbackOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface ContinueUpdateRollbackCommandInput
  extends ContinueUpdateRollbackInput {}
export interface ContinueUpdateRollbackCommandOutput
  extends ContinueUpdateRollbackOutput,
    __MetadataBearer {}
declare const ContinueUpdateRollbackCommand_base: {
  new (
    input: ContinueUpdateRollbackCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ContinueUpdateRollbackCommandInput,
    ContinueUpdateRollbackCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ContinueUpdateRollbackCommand extends ContinueUpdateRollbackCommand_base {}
