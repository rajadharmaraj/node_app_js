import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeChangeSetInput,
  DescribeChangeSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeChangeSetCommandInput extends DescribeChangeSetInput {}
export interface DescribeChangeSetCommandOutput
  extends DescribeChangeSetOutput,
    __MetadataBearer {}
declare const DescribeChangeSetCommand_base: {
  new (
    input: DescribeChangeSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeChangeSetCommandInput,
    DescribeChangeSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeChangeSetCommand extends DescribeChangeSetCommand_base {}
