import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackInstanceInput,
  DescribeStackInstanceOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackInstanceCommandInput
  extends DescribeStackInstanceInput {}
export interface DescribeStackInstanceCommandOutput
  extends DescribeStackInstanceOutput,
    __MetadataBearer {}
declare const DescribeStackInstanceCommand_base: {
  new (
    input: DescribeStackInstanceCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackInstanceCommandInput,
    DescribeStackInstanceCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackInstanceCommand extends DescribeStackInstanceCommand_base {}
