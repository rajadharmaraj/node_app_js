import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DetectStackDriftInput,
  DetectStackDriftOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DetectStackDriftCommandInput extends DetectStackDriftInput {}
export interface DetectStackDriftCommandOutput
  extends DetectStackDriftOutput,
    __MetadataBearer {}
declare const DetectStackDriftCommand_base: {
  new (
    input: DetectStackDriftCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DetectStackDriftCommandInput,
    DetectStackDriftCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DetectStackDriftCommand extends DetectStackDriftCommand_base {}
