import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeTypeRegistrationInput,
  DescribeTypeRegistrationOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeTypeRegistrationCommandInput
  extends DescribeTypeRegistrationInput {}
export interface DescribeTypeRegistrationCommandOutput
  extends DescribeTypeRegistrationOutput,
    __MetadataBearer {}
declare const DescribeTypeRegistrationCommand_base: {
  new (
    input: DescribeTypeRegistrationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeTypeRegistrationCommandInput,
    DescribeTypeRegistrationCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeTypeRegistrationCommand extends DescribeTypeRegistrationCommand_base {}
