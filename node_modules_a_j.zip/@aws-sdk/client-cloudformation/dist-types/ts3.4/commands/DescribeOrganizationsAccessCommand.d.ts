import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeOrganizationsAccessInput,
  DescribeOrganizationsAccessOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeOrganizationsAccessCommandInput
  extends DescribeOrganizationsAccessInput {}
export interface DescribeOrganizationsAccessCommandOutput
  extends DescribeOrganizationsAccessOutput,
    __MetadataBearer {}
declare const DescribeOrganizationsAccessCommand_base: {
  new (
    input: DescribeOrganizationsAccessCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeOrganizationsAccessCommandInput,
    DescribeOrganizationsAccessCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeOrganizationsAccessCommand extends DescribeOrganizationsAccessCommand_base {}
