import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribePublisherInput,
  DescribePublisherOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribePublisherCommandInput extends DescribePublisherInput {}
export interface DescribePublisherCommandOutput
  extends DescribePublisherOutput,
    __MetadataBearer {}
declare const DescribePublisherCommand_base: {
  new (
    input: DescribePublisherCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribePublisherCommandInput,
    DescribePublisherCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribePublisherCommand extends DescribePublisherCommand_base {}
