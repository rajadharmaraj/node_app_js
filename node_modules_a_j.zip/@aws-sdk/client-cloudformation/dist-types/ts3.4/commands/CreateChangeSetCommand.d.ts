import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  CreateChangeSetInput,
  CreateChangeSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CreateChangeSetCommandInput extends CreateChangeSetInput {}
export interface CreateChangeSetCommandOutput
  extends CreateChangeSetOutput,
    __MetadataBearer {}
declare const CreateChangeSetCommand_base: {
  new (
    input: CreateChangeSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateChangeSetCommandInput,
    CreateChangeSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateChangeSetCommand extends CreateChangeSetCommand_base {}
