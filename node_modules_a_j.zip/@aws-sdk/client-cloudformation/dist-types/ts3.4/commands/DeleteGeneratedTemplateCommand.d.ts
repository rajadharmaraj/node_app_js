import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import { DeleteGeneratedTemplateInput } from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DeleteGeneratedTemplateCommandInput
  extends DeleteGeneratedTemplateInput {}
export interface DeleteGeneratedTemplateCommandOutput
  extends __MetadataBearer {}
declare const DeleteGeneratedTemplateCommand_base: {
  new (
    input: DeleteGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteGeneratedTemplateCommandInput,
    DeleteGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteGeneratedTemplateCommand extends DeleteGeneratedTemplateCommand_base {}
