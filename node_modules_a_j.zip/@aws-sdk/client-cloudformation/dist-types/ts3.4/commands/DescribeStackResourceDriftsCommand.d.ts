import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackResourceDriftsInput,
  DescribeStackResourceDriftsOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackResourceDriftsCommandInput
  extends DescribeStackResourceDriftsInput {}
export interface DescribeStackResourceDriftsCommandOutput
  extends DescribeStackResourceDriftsOutput,
    __MetadataBearer {}
declare const DescribeStackResourceDriftsCommand_base: {
  new (
    input: DescribeStackResourceDriftsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackResourceDriftsCommandInput,
    DescribeStackResourceDriftsCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackResourceDriftsCommand extends DescribeStackResourceDriftsCommand_base {}
