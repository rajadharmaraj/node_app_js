import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  DescribeStackSetInput,
  DescribeStackSetOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface DescribeStackSetCommandInput extends DescribeStackSetInput {}
export interface DescribeStackSetCommandOutput
  extends DescribeStackSetOutput,
    __MetadataBearer {}
declare const DescribeStackSetCommand_base: {
  new (
    input: DescribeStackSetCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeStackSetCommandInput,
    DescribeStackSetCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeStackSetCommand extends DescribeStackSetCommand_base {}
