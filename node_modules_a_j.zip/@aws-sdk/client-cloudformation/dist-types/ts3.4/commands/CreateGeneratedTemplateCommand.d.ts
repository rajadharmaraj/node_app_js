import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CloudFormationClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../CloudFormationClient";
import {
  CreateGeneratedTemplateInput,
  CreateGeneratedTemplateOutput,
} from "../models/models_0";
export { __MetadataBearer, $Command };
export interface CreateGeneratedTemplateCommandInput
  extends CreateGeneratedTemplateInput {}
export interface CreateGeneratedTemplateCommandOutput
  extends CreateGeneratedTemplateOutput,
    __MetadataBearer {}
declare const CreateGeneratedTemplateCommand_base: {
  new (
    input: CreateGeneratedTemplateCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateGeneratedTemplateCommandInput,
    CreateGeneratedTemplateCommandOutput,
    CloudFormationClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateGeneratedTemplateCommand extends CreateGeneratedTemplateCommand_base {}
