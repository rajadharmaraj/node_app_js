import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SerdeContext as __SerdeContext } from "@smithy/types";
import { ActivateOrganizationsAccessCommandInput, ActivateOrganizationsAccessCommandOutput } from "../commands/ActivateOrganizationsAccessCommand";
import { ActivateTypeCommandInput, ActivateTypeCommandOutput } from "../commands/ActivateTypeCommand";
import { BatchDescribeTypeConfigurationsCommandInput, BatchDescribeTypeConfigurationsCommandOutput } from "../commands/BatchDescribeTypeConfigurationsCommand";
import { CancelUpdateStackCommandInput, CancelUpdateStackCommandOutput } from "../commands/CancelUpdateStackCommand";
import { ContinueUpdateRollbackCommandInput, ContinueUpdateRollbackCommandOutput } from "../commands/ContinueUpdateRollbackCommand";
import { CreateChangeSetCommandInput, CreateChangeSetCommandOutput } from "../commands/CreateChangeSetCommand";
import { CreateGeneratedTemplateCommandInput, CreateGeneratedTemplateCommandOutput } from "../commands/CreateGeneratedTemplateCommand";
import { CreateStackCommandInput, CreateStackCommandOutput } from "../commands/CreateStackCommand";
import { CreateStackInstancesCommandInput, CreateStackInstancesCommandOutput } from "../commands/CreateStackInstancesCommand";
import { CreateStackSetCommandInput, CreateStackSetCommandOutput } from "../commands/CreateStackSetCommand";
import { DeactivateOrganizationsAccessCommandInput, DeactivateOrganizationsAccessCommandOutput } from "../commands/DeactivateOrganizationsAccessCommand";
import { DeactivateTypeCommandInput, DeactivateTypeCommandOutput } from "../commands/DeactivateTypeCommand";
import { DeleteChangeSetCommandInput, DeleteChangeSetCommandOutput } from "../commands/DeleteChangeSetCommand";
import { DeleteGeneratedTemplateCommandInput, DeleteGeneratedTemplateCommandOutput } from "../commands/DeleteGeneratedTemplateCommand";
import { DeleteStackCommandInput, DeleteStackCommandOutput } from "../commands/DeleteStackCommand";
import { DeleteStackInstancesCommandInput, DeleteStackInstancesCommandOutput } from "../commands/DeleteStackInstancesCommand";
import { DeleteStackSetCommandInput, DeleteStackSetCommandOutput } from "../commands/DeleteStackSetCommand";
import { DeregisterTypeCommandInput, DeregisterTypeCommandOutput } from "../commands/DeregisterTypeCommand";
import { DescribeAccountLimitsCommandInput, DescribeAccountLimitsCommandOutput } from "../commands/DescribeAccountLimitsCommand";
import { DescribeChangeSetCommandInput, DescribeChangeSetCommandOutput } from "../commands/DescribeChangeSetCommand";
import { DescribeChangeSetHooksCommandInput, DescribeChangeSetHooksCommandOutput } from "../commands/DescribeChangeSetHooksCommand";
import { DescribeGeneratedTemplateCommandInput, DescribeGeneratedTemplateCommandOutput } from "../commands/DescribeGeneratedTemplateCommand";
import { DescribeOrganizationsAccessCommandInput, DescribeOrganizationsAccessCommandOutput } from "../commands/DescribeOrganizationsAccessCommand";
import { DescribePublisherCommandInput, DescribePublisherCommandOutput } from "../commands/DescribePublisherCommand";
import { DescribeResourceScanCommandInput, DescribeResourceScanCommandOutput } from "../commands/DescribeResourceScanCommand";
import { DescribeStackDriftDetectionStatusCommandInput, DescribeStackDriftDetectionStatusCommandOutput } from "../commands/DescribeStackDriftDetectionStatusCommand";
import { DescribeStackEventsCommandInput, DescribeStackEventsCommandOutput } from "../commands/DescribeStackEventsCommand";
import { DescribeStackInstanceCommandInput, DescribeStackInstanceCommandOutput } from "../commands/DescribeStackInstanceCommand";
import { DescribeStackResourceCommandInput, DescribeStackResourceCommandOutput } from "../commands/DescribeStackResourceCommand";
import { DescribeStackResourceDriftsCommandInput, DescribeStackResourceDriftsCommandOutput } from "../commands/DescribeStackResourceDriftsCommand";
import { DescribeStackResourcesCommandInput, DescribeStackResourcesCommandOutput } from "../commands/DescribeStackResourcesCommand";
import { DescribeStacksCommandInput, DescribeStacksCommandOutput } from "../commands/DescribeStacksCommand";
import { DescribeStackSetCommandInput, DescribeStackSetCommandOutput } from "../commands/DescribeStackSetCommand";
import { DescribeStackSetOperationCommandInput, DescribeStackSetOperationCommandOutput } from "../commands/DescribeStackSetOperationCommand";
import { DescribeTypeCommandInput, DescribeTypeCommandOutput } from "../commands/DescribeTypeCommand";
import { DescribeTypeRegistrationCommandInput, DescribeTypeRegistrationCommandOutput } from "../commands/DescribeTypeRegistrationCommand";
import { DetectStackDriftCommandInput, DetectStackDriftCommandOutput } from "../commands/DetectStackDriftCommand";
import { DetectStackResourceDriftCommandInput, DetectStackResourceDriftCommandOutput } from "../commands/DetectStackResourceDriftCommand";
import { DetectStackSetDriftCommandInput, DetectStackSetDriftCommandOutput } from "../commands/DetectStackSetDriftCommand";
import { EstimateTemplateCostCommandInput, EstimateTemplateCostCommandOutput } from "../commands/EstimateTemplateCostCommand";
import { ExecuteChangeSetCommandInput, ExecuteChangeSetCommandOutput } from "../commands/ExecuteChangeSetCommand";
import { GetGeneratedTemplateCommandInput, GetGeneratedTemplateCommandOutput } from "../commands/GetGeneratedTemplateCommand";
import { GetStackPolicyCommandInput, GetStackPolicyCommandOutput } from "../commands/GetStackPolicyCommand";
import { GetTemplateCommandInput, GetTemplateCommandOutput } from "../commands/GetTemplateCommand";
import { GetTemplateSummaryCommandInput, GetTemplateSummaryCommandOutput } from "../commands/GetTemplateSummaryCommand";
import { ImportStacksToStackSetCommandInput, ImportStacksToStackSetCommandOutput } from "../commands/ImportStacksToStackSetCommand";
import { ListChangeSetsCommandInput, ListChangeSetsCommandOutput } from "../commands/ListChangeSetsCommand";
import { ListExportsCommandInput, ListExportsCommandOutput } from "../commands/ListExportsCommand";
import { ListGeneratedTemplatesCommandInput, ListGeneratedTemplatesCommandOutput } from "../commands/ListGeneratedTemplatesCommand";
import { ListImportsCommandInput, ListImportsCommandOutput } from "../commands/ListImportsCommand";
import { ListResourceScanRelatedResourcesCommandInput, ListResourceScanRelatedResourcesCommandOutput } from "../commands/ListResourceScanRelatedResourcesCommand";
import { ListResourceScanResourcesCommandInput, ListResourceScanResourcesCommandOutput } from "../commands/ListResourceScanResourcesCommand";
import { ListResourceScansCommandInput, ListResourceScansCommandOutput } from "../commands/ListResourceScansCommand";
import { ListStackInstanceResourceDriftsCommandInput, ListStackInstanceResourceDriftsCommandOutput } from "../commands/ListStackInstanceResourceDriftsCommand";
import { ListStackInstancesCommandInput, ListStackInstancesCommandOutput } from "../commands/ListStackInstancesCommand";
import { ListStackResourcesCommandInput, ListStackResourcesCommandOutput } from "../commands/ListStackResourcesCommand";
import { ListStacksCommandInput, ListStacksCommandOutput } from "../commands/ListStacksCommand";
import { ListStackSetOperationResultsCommandInput, ListStackSetOperationResultsCommandOutput } from "../commands/ListStackSetOperationResultsCommand";
import { ListStackSetOperationsCommandInput, ListStackSetOperationsCommandOutput } from "../commands/ListStackSetOperationsCommand";
import { ListStackSetsCommandInput, ListStackSetsCommandOutput } from "../commands/ListStackSetsCommand";
import { ListTypeRegistrationsCommandInput, ListTypeRegistrationsCommandOutput } from "../commands/ListTypeRegistrationsCommand";
import { ListTypesCommandInput, ListTypesCommandOutput } from "../commands/ListTypesCommand";
import { ListTypeVersionsCommandInput, ListTypeVersionsCommandOutput } from "../commands/ListTypeVersionsCommand";
import { PublishTypeCommandInput, PublishTypeCommandOutput } from "../commands/PublishTypeCommand";
import { RecordHandlerProgressCommandInput, RecordHandlerProgressCommandOutput } from "../commands/RecordHandlerProgressCommand";
import { RegisterPublisherCommandInput, RegisterPublisherCommandOutput } from "../commands/RegisterPublisherCommand";
import { RegisterTypeCommandInput, RegisterTypeCommandOutput } from "../commands/RegisterTypeCommand";
import { RollbackStackCommandInput, RollbackStackCommandOutput } from "../commands/RollbackStackCommand";
import { SetStackPolicyCommandInput, SetStackPolicyCommandOutput } from "../commands/SetStackPolicyCommand";
import { SetTypeConfigurationCommandInput, SetTypeConfigurationCommandOutput } from "../commands/SetTypeConfigurationCommand";
import { SetTypeDefaultVersionCommandInput, SetTypeDefaultVersionCommandOutput } from "../commands/SetTypeDefaultVersionCommand";
import { SignalResourceCommandInput, SignalResourceCommandOutput } from "../commands/SignalResourceCommand";
import { StartResourceScanCommandInput, StartResourceScanCommandOutput } from "../commands/StartResourceScanCommand";
import { StopStackSetOperationCommandInput, StopStackSetOperationCommandOutput } from "../commands/StopStackSetOperationCommand";
import { TestTypeCommandInput, TestTypeCommandOutput } from "../commands/TestTypeCommand";
import { UpdateGeneratedTemplateCommandInput, UpdateGeneratedTemplateCommandOutput } from "../commands/UpdateGeneratedTemplateCommand";
import { UpdateStackCommandInput, UpdateStackCommandOutput } from "../commands/UpdateStackCommand";
import { UpdateStackInstancesCommandInput, UpdateStackInstancesCommandOutput } from "../commands/UpdateStackInstancesCommand";
import { UpdateStackSetCommandInput, UpdateStackSetCommandOutput } from "../commands/UpdateStackSetCommand";
import { UpdateTerminationProtectionCommandInput, UpdateTerminationProtectionCommandOutput } from "../commands/UpdateTerminationProtectionCommand";
import { ValidateTemplateCommandInput, ValidateTemplateCommandOutput } from "../commands/ValidateTemplateCommand";
/**
 * serializeAws_queryActivateOrganizationsAccessCommand
 */
export declare const se_ActivateOrganizationsAccessCommand: (input: ActivateOrganizationsAccessCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryActivateTypeCommand
 */
export declare const se_ActivateTypeCommand: (input: ActivateTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryBatchDescribeTypeConfigurationsCommand
 */
export declare const se_BatchDescribeTypeConfigurationsCommand: (input: BatchDescribeTypeConfigurationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCancelUpdateStackCommand
 */
export declare const se_CancelUpdateStackCommand: (input: CancelUpdateStackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryContinueUpdateRollbackCommand
 */
export declare const se_ContinueUpdateRollbackCommand: (input: ContinueUpdateRollbackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCreateChangeSetCommand
 */
export declare const se_CreateChangeSetCommand: (input: CreateChangeSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCreateGeneratedTemplateCommand
 */
export declare const se_CreateGeneratedTemplateCommand: (input: CreateGeneratedTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCreateStackCommand
 */
export declare const se_CreateStackCommand: (input: CreateStackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCreateStackInstancesCommand
 */
export declare const se_CreateStackInstancesCommand: (input: CreateStackInstancesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryCreateStackSetCommand
 */
export declare const se_CreateStackSetCommand: (input: CreateStackSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeactivateOrganizationsAccessCommand
 */
export declare const se_DeactivateOrganizationsAccessCommand: (input: DeactivateOrganizationsAccessCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeactivateTypeCommand
 */
export declare const se_DeactivateTypeCommand: (input: DeactivateTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeleteChangeSetCommand
 */
export declare const se_DeleteChangeSetCommand: (input: DeleteChangeSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeleteGeneratedTemplateCommand
 */
export declare const se_DeleteGeneratedTemplateCommand: (input: DeleteGeneratedTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeleteStackCommand
 */
export declare const se_DeleteStackCommand: (input: DeleteStackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeleteStackInstancesCommand
 */
export declare const se_DeleteStackInstancesCommand: (input: DeleteStackInstancesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeleteStackSetCommand
 */
export declare const se_DeleteStackSetCommand: (input: DeleteStackSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDeregisterTypeCommand
 */
export declare const se_DeregisterTypeCommand: (input: DeregisterTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeAccountLimitsCommand
 */
export declare const se_DescribeAccountLimitsCommand: (input: DescribeAccountLimitsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeChangeSetCommand
 */
export declare const se_DescribeChangeSetCommand: (input: DescribeChangeSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeChangeSetHooksCommand
 */
export declare const se_DescribeChangeSetHooksCommand: (input: DescribeChangeSetHooksCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeGeneratedTemplateCommand
 */
export declare const se_DescribeGeneratedTemplateCommand: (input: DescribeGeneratedTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeOrganizationsAccessCommand
 */
export declare const se_DescribeOrganizationsAccessCommand: (input: DescribeOrganizationsAccessCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribePublisherCommand
 */
export declare const se_DescribePublisherCommand: (input: DescribePublisherCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeResourceScanCommand
 */
export declare const se_DescribeResourceScanCommand: (input: DescribeResourceScanCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackDriftDetectionStatusCommand
 */
export declare const se_DescribeStackDriftDetectionStatusCommand: (input: DescribeStackDriftDetectionStatusCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackEventsCommand
 */
export declare const se_DescribeStackEventsCommand: (input: DescribeStackEventsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackInstanceCommand
 */
export declare const se_DescribeStackInstanceCommand: (input: DescribeStackInstanceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackResourceCommand
 */
export declare const se_DescribeStackResourceCommand: (input: DescribeStackResourceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackResourceDriftsCommand
 */
export declare const se_DescribeStackResourceDriftsCommand: (input: DescribeStackResourceDriftsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackResourcesCommand
 */
export declare const se_DescribeStackResourcesCommand: (input: DescribeStackResourcesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStacksCommand
 */
export declare const se_DescribeStacksCommand: (input: DescribeStacksCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackSetCommand
 */
export declare const se_DescribeStackSetCommand: (input: DescribeStackSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeStackSetOperationCommand
 */
export declare const se_DescribeStackSetOperationCommand: (input: DescribeStackSetOperationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeTypeCommand
 */
export declare const se_DescribeTypeCommand: (input: DescribeTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDescribeTypeRegistrationCommand
 */
export declare const se_DescribeTypeRegistrationCommand: (input: DescribeTypeRegistrationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDetectStackDriftCommand
 */
export declare const se_DetectStackDriftCommand: (input: DetectStackDriftCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDetectStackResourceDriftCommand
 */
export declare const se_DetectStackResourceDriftCommand: (input: DetectStackResourceDriftCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryDetectStackSetDriftCommand
 */
export declare const se_DetectStackSetDriftCommand: (input: DetectStackSetDriftCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryEstimateTemplateCostCommand
 */
export declare const se_EstimateTemplateCostCommand: (input: EstimateTemplateCostCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryExecuteChangeSetCommand
 */
export declare const se_ExecuteChangeSetCommand: (input: ExecuteChangeSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryGetGeneratedTemplateCommand
 */
export declare const se_GetGeneratedTemplateCommand: (input: GetGeneratedTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryGetStackPolicyCommand
 */
export declare const se_GetStackPolicyCommand: (input: GetStackPolicyCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryGetTemplateCommand
 */
export declare const se_GetTemplateCommand: (input: GetTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryGetTemplateSummaryCommand
 */
export declare const se_GetTemplateSummaryCommand: (input: GetTemplateSummaryCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryImportStacksToStackSetCommand
 */
export declare const se_ImportStacksToStackSetCommand: (input: ImportStacksToStackSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListChangeSetsCommand
 */
export declare const se_ListChangeSetsCommand: (input: ListChangeSetsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListExportsCommand
 */
export declare const se_ListExportsCommand: (input: ListExportsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListGeneratedTemplatesCommand
 */
export declare const se_ListGeneratedTemplatesCommand: (input: ListGeneratedTemplatesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListImportsCommand
 */
export declare const se_ListImportsCommand: (input: ListImportsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListResourceScanRelatedResourcesCommand
 */
export declare const se_ListResourceScanRelatedResourcesCommand: (input: ListResourceScanRelatedResourcesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListResourceScanResourcesCommand
 */
export declare const se_ListResourceScanResourcesCommand: (input: ListResourceScanResourcesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListResourceScansCommand
 */
export declare const se_ListResourceScansCommand: (input: ListResourceScansCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackInstanceResourceDriftsCommand
 */
export declare const se_ListStackInstanceResourceDriftsCommand: (input: ListStackInstanceResourceDriftsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackInstancesCommand
 */
export declare const se_ListStackInstancesCommand: (input: ListStackInstancesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackResourcesCommand
 */
export declare const se_ListStackResourcesCommand: (input: ListStackResourcesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStacksCommand
 */
export declare const se_ListStacksCommand: (input: ListStacksCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackSetOperationResultsCommand
 */
export declare const se_ListStackSetOperationResultsCommand: (input: ListStackSetOperationResultsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackSetOperationsCommand
 */
export declare const se_ListStackSetOperationsCommand: (input: ListStackSetOperationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListStackSetsCommand
 */
export declare const se_ListStackSetsCommand: (input: ListStackSetsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListTypeRegistrationsCommand
 */
export declare const se_ListTypeRegistrationsCommand: (input: ListTypeRegistrationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListTypesCommand
 */
export declare const se_ListTypesCommand: (input: ListTypesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryListTypeVersionsCommand
 */
export declare const se_ListTypeVersionsCommand: (input: ListTypeVersionsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryPublishTypeCommand
 */
export declare const se_PublishTypeCommand: (input: PublishTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryRecordHandlerProgressCommand
 */
export declare const se_RecordHandlerProgressCommand: (input: RecordHandlerProgressCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryRegisterPublisherCommand
 */
export declare const se_RegisterPublisherCommand: (input: RegisterPublisherCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryRegisterTypeCommand
 */
export declare const se_RegisterTypeCommand: (input: RegisterTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryRollbackStackCommand
 */
export declare const se_RollbackStackCommand: (input: RollbackStackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_querySetStackPolicyCommand
 */
export declare const se_SetStackPolicyCommand: (input: SetStackPolicyCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_querySetTypeConfigurationCommand
 */
export declare const se_SetTypeConfigurationCommand: (input: SetTypeConfigurationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_querySetTypeDefaultVersionCommand
 */
export declare const se_SetTypeDefaultVersionCommand: (input: SetTypeDefaultVersionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_querySignalResourceCommand
 */
export declare const se_SignalResourceCommand: (input: SignalResourceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryStartResourceScanCommand
 */
export declare const se_StartResourceScanCommand: (input: StartResourceScanCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryStopStackSetOperationCommand
 */
export declare const se_StopStackSetOperationCommand: (input: StopStackSetOperationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryTestTypeCommand
 */
export declare const se_TestTypeCommand: (input: TestTypeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryUpdateGeneratedTemplateCommand
 */
export declare const se_UpdateGeneratedTemplateCommand: (input: UpdateGeneratedTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryUpdateStackCommand
 */
export declare const se_UpdateStackCommand: (input: UpdateStackCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryUpdateStackInstancesCommand
 */
export declare const se_UpdateStackInstancesCommand: (input: UpdateStackInstancesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryUpdateStackSetCommand
 */
export declare const se_UpdateStackSetCommand: (input: UpdateStackSetCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryUpdateTerminationProtectionCommand
 */
export declare const se_UpdateTerminationProtectionCommand: (input: UpdateTerminationProtectionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_queryValidateTemplateCommand
 */
export declare const se_ValidateTemplateCommand: (input: ValidateTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_queryActivateOrganizationsAccessCommand
 */
export declare const de_ActivateOrganizationsAccessCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ActivateOrganizationsAccessCommandOutput>;
/**
 * deserializeAws_queryActivateTypeCommand
 */
export declare const de_ActivateTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ActivateTypeCommandOutput>;
/**
 * deserializeAws_queryBatchDescribeTypeConfigurationsCommand
 */
export declare const de_BatchDescribeTypeConfigurationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<BatchDescribeTypeConfigurationsCommandOutput>;
/**
 * deserializeAws_queryCancelUpdateStackCommand
 */
export declare const de_CancelUpdateStackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CancelUpdateStackCommandOutput>;
/**
 * deserializeAws_queryContinueUpdateRollbackCommand
 */
export declare const de_ContinueUpdateRollbackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ContinueUpdateRollbackCommandOutput>;
/**
 * deserializeAws_queryCreateChangeSetCommand
 */
export declare const de_CreateChangeSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateChangeSetCommandOutput>;
/**
 * deserializeAws_queryCreateGeneratedTemplateCommand
 */
export declare const de_CreateGeneratedTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateGeneratedTemplateCommandOutput>;
/**
 * deserializeAws_queryCreateStackCommand
 */
export declare const de_CreateStackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateStackCommandOutput>;
/**
 * deserializeAws_queryCreateStackInstancesCommand
 */
export declare const de_CreateStackInstancesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateStackInstancesCommandOutput>;
/**
 * deserializeAws_queryCreateStackSetCommand
 */
export declare const de_CreateStackSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateStackSetCommandOutput>;
/**
 * deserializeAws_queryDeactivateOrganizationsAccessCommand
 */
export declare const de_DeactivateOrganizationsAccessCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeactivateOrganizationsAccessCommandOutput>;
/**
 * deserializeAws_queryDeactivateTypeCommand
 */
export declare const de_DeactivateTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeactivateTypeCommandOutput>;
/**
 * deserializeAws_queryDeleteChangeSetCommand
 */
export declare const de_DeleteChangeSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteChangeSetCommandOutput>;
/**
 * deserializeAws_queryDeleteGeneratedTemplateCommand
 */
export declare const de_DeleteGeneratedTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteGeneratedTemplateCommandOutput>;
/**
 * deserializeAws_queryDeleteStackCommand
 */
export declare const de_DeleteStackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteStackCommandOutput>;
/**
 * deserializeAws_queryDeleteStackInstancesCommand
 */
export declare const de_DeleteStackInstancesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteStackInstancesCommandOutput>;
/**
 * deserializeAws_queryDeleteStackSetCommand
 */
export declare const de_DeleteStackSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteStackSetCommandOutput>;
/**
 * deserializeAws_queryDeregisterTypeCommand
 */
export declare const de_DeregisterTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeregisterTypeCommandOutput>;
/**
 * deserializeAws_queryDescribeAccountLimitsCommand
 */
export declare const de_DescribeAccountLimitsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeAccountLimitsCommandOutput>;
/**
 * deserializeAws_queryDescribeChangeSetCommand
 */
export declare const de_DescribeChangeSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeChangeSetCommandOutput>;
/**
 * deserializeAws_queryDescribeChangeSetHooksCommand
 */
export declare const de_DescribeChangeSetHooksCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeChangeSetHooksCommandOutput>;
/**
 * deserializeAws_queryDescribeGeneratedTemplateCommand
 */
export declare const de_DescribeGeneratedTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeGeneratedTemplateCommandOutput>;
/**
 * deserializeAws_queryDescribeOrganizationsAccessCommand
 */
export declare const de_DescribeOrganizationsAccessCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeOrganizationsAccessCommandOutput>;
/**
 * deserializeAws_queryDescribePublisherCommand
 */
export declare const de_DescribePublisherCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribePublisherCommandOutput>;
/**
 * deserializeAws_queryDescribeResourceScanCommand
 */
export declare const de_DescribeResourceScanCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeResourceScanCommandOutput>;
/**
 * deserializeAws_queryDescribeStackDriftDetectionStatusCommand
 */
export declare const de_DescribeStackDriftDetectionStatusCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackDriftDetectionStatusCommandOutput>;
/**
 * deserializeAws_queryDescribeStackEventsCommand
 */
export declare const de_DescribeStackEventsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackEventsCommandOutput>;
/**
 * deserializeAws_queryDescribeStackInstanceCommand
 */
export declare const de_DescribeStackInstanceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackInstanceCommandOutput>;
/**
 * deserializeAws_queryDescribeStackResourceCommand
 */
export declare const de_DescribeStackResourceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackResourceCommandOutput>;
/**
 * deserializeAws_queryDescribeStackResourceDriftsCommand
 */
export declare const de_DescribeStackResourceDriftsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackResourceDriftsCommandOutput>;
/**
 * deserializeAws_queryDescribeStackResourcesCommand
 */
export declare const de_DescribeStackResourcesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackResourcesCommandOutput>;
/**
 * deserializeAws_queryDescribeStacksCommand
 */
export declare const de_DescribeStacksCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStacksCommandOutput>;
/**
 * deserializeAws_queryDescribeStackSetCommand
 */
export declare const de_DescribeStackSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackSetCommandOutput>;
/**
 * deserializeAws_queryDescribeStackSetOperationCommand
 */
export declare const de_DescribeStackSetOperationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeStackSetOperationCommandOutput>;
/**
 * deserializeAws_queryDescribeTypeCommand
 */
export declare const de_DescribeTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeTypeCommandOutput>;
/**
 * deserializeAws_queryDescribeTypeRegistrationCommand
 */
export declare const de_DescribeTypeRegistrationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeTypeRegistrationCommandOutput>;
/**
 * deserializeAws_queryDetectStackDriftCommand
 */
export declare const de_DetectStackDriftCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DetectStackDriftCommandOutput>;
/**
 * deserializeAws_queryDetectStackResourceDriftCommand
 */
export declare const de_DetectStackResourceDriftCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DetectStackResourceDriftCommandOutput>;
/**
 * deserializeAws_queryDetectStackSetDriftCommand
 */
export declare const de_DetectStackSetDriftCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DetectStackSetDriftCommandOutput>;
/**
 * deserializeAws_queryEstimateTemplateCostCommand
 */
export declare const de_EstimateTemplateCostCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<EstimateTemplateCostCommandOutput>;
/**
 * deserializeAws_queryExecuteChangeSetCommand
 */
export declare const de_ExecuteChangeSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ExecuteChangeSetCommandOutput>;
/**
 * deserializeAws_queryGetGeneratedTemplateCommand
 */
export declare const de_GetGeneratedTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetGeneratedTemplateCommandOutput>;
/**
 * deserializeAws_queryGetStackPolicyCommand
 */
export declare const de_GetStackPolicyCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetStackPolicyCommandOutput>;
/**
 * deserializeAws_queryGetTemplateCommand
 */
export declare const de_GetTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetTemplateCommandOutput>;
/**
 * deserializeAws_queryGetTemplateSummaryCommand
 */
export declare const de_GetTemplateSummaryCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetTemplateSummaryCommandOutput>;
/**
 * deserializeAws_queryImportStacksToStackSetCommand
 */
export declare const de_ImportStacksToStackSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ImportStacksToStackSetCommandOutput>;
/**
 * deserializeAws_queryListChangeSetsCommand
 */
export declare const de_ListChangeSetsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListChangeSetsCommandOutput>;
/**
 * deserializeAws_queryListExportsCommand
 */
export declare const de_ListExportsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListExportsCommandOutput>;
/**
 * deserializeAws_queryListGeneratedTemplatesCommand
 */
export declare const de_ListGeneratedTemplatesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListGeneratedTemplatesCommandOutput>;
/**
 * deserializeAws_queryListImportsCommand
 */
export declare const de_ListImportsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListImportsCommandOutput>;
/**
 * deserializeAws_queryListResourceScanRelatedResourcesCommand
 */
export declare const de_ListResourceScanRelatedResourcesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListResourceScanRelatedResourcesCommandOutput>;
/**
 * deserializeAws_queryListResourceScanResourcesCommand
 */
export declare const de_ListResourceScanResourcesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListResourceScanResourcesCommandOutput>;
/**
 * deserializeAws_queryListResourceScansCommand
 */
export declare const de_ListResourceScansCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListResourceScansCommandOutput>;
/**
 * deserializeAws_queryListStackInstanceResourceDriftsCommand
 */
export declare const de_ListStackInstanceResourceDriftsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackInstanceResourceDriftsCommandOutput>;
/**
 * deserializeAws_queryListStackInstancesCommand
 */
export declare const de_ListStackInstancesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackInstancesCommandOutput>;
/**
 * deserializeAws_queryListStackResourcesCommand
 */
export declare const de_ListStackResourcesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackResourcesCommandOutput>;
/**
 * deserializeAws_queryListStacksCommand
 */
export declare const de_ListStacksCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStacksCommandOutput>;
/**
 * deserializeAws_queryListStackSetOperationResultsCommand
 */
export declare const de_ListStackSetOperationResultsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackSetOperationResultsCommandOutput>;
/**
 * deserializeAws_queryListStackSetOperationsCommand
 */
export declare const de_ListStackSetOperationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackSetOperationsCommandOutput>;
/**
 * deserializeAws_queryListStackSetsCommand
 */
export declare const de_ListStackSetsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStackSetsCommandOutput>;
/**
 * deserializeAws_queryListTypeRegistrationsCommand
 */
export declare const de_ListTypeRegistrationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListTypeRegistrationsCommandOutput>;
/**
 * deserializeAws_queryListTypesCommand
 */
export declare const de_ListTypesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListTypesCommandOutput>;
/**
 * deserializeAws_queryListTypeVersionsCommand
 */
export declare const de_ListTypeVersionsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListTypeVersionsCommandOutput>;
/**
 * deserializeAws_queryPublishTypeCommand
 */
export declare const de_PublishTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<PublishTypeCommandOutput>;
/**
 * deserializeAws_queryRecordHandlerProgressCommand
 */
export declare const de_RecordHandlerProgressCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RecordHandlerProgressCommandOutput>;
/**
 * deserializeAws_queryRegisterPublisherCommand
 */
export declare const de_RegisterPublisherCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RegisterPublisherCommandOutput>;
/**
 * deserializeAws_queryRegisterTypeCommand
 */
export declare const de_RegisterTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RegisterTypeCommandOutput>;
/**
 * deserializeAws_queryRollbackStackCommand
 */
export declare const de_RollbackStackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RollbackStackCommandOutput>;
/**
 * deserializeAws_querySetStackPolicyCommand
 */
export declare const de_SetStackPolicyCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SetStackPolicyCommandOutput>;
/**
 * deserializeAws_querySetTypeConfigurationCommand
 */
export declare const de_SetTypeConfigurationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SetTypeConfigurationCommandOutput>;
/**
 * deserializeAws_querySetTypeDefaultVersionCommand
 */
export declare const de_SetTypeDefaultVersionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SetTypeDefaultVersionCommandOutput>;
/**
 * deserializeAws_querySignalResourceCommand
 */
export declare const de_SignalResourceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SignalResourceCommandOutput>;
/**
 * deserializeAws_queryStartResourceScanCommand
 */
export declare const de_StartResourceScanCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<StartResourceScanCommandOutput>;
/**
 * deserializeAws_queryStopStackSetOperationCommand
 */
export declare const de_StopStackSetOperationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<StopStackSetOperationCommandOutput>;
/**
 * deserializeAws_queryTestTypeCommand
 */
export declare const de_TestTypeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<TestTypeCommandOutput>;
/**
 * deserializeAws_queryUpdateGeneratedTemplateCommand
 */
export declare const de_UpdateGeneratedTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateGeneratedTemplateCommandOutput>;
/**
 * deserializeAws_queryUpdateStackCommand
 */
export declare const de_UpdateStackCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateStackCommandOutput>;
/**
 * deserializeAws_queryUpdateStackInstancesCommand
 */
export declare const de_UpdateStackInstancesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateStackInstancesCommandOutput>;
/**
 * deserializeAws_queryUpdateStackSetCommand
 */
export declare const de_UpdateStackSetCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateStackSetCommandOutput>;
/**
 * deserializeAws_queryUpdateTerminationProtectionCommand
 */
export declare const de_UpdateTerminationProtectionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateTerminationProtectionCommandOutput>;
/**
 * deserializeAws_queryValidateTemplateCommand
 */
export declare const de_ValidateTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ValidateTemplateCommandOutput>;
