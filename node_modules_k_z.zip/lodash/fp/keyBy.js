var convert = require('./convert'),
    func = convert('keyBy', require('../keyBy'));

func.placeholder = require('./placeholder');
module.exports = func;
