var convert = require('./convert'),
    func = convert('pick', require('../pick'));

func.placeholder = require('./placeholder');
module.exports = func;
