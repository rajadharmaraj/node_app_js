var convert = require('./convert'),
    func = convert('snakeCase', require('../snakeCase'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
