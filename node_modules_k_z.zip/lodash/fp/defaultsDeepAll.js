var convert = require('./convert'),
    func = convert('defaultsDeepAll', require('../defaultsDeep'));

func.placeholder = require('./placeholder');
module.exports = func;
