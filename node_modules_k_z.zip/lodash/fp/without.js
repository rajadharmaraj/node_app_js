var convert = require('./convert'),
    func = convert('without', require('../without'));

func.placeholder = require('./placeholder');
module.exports = func;
