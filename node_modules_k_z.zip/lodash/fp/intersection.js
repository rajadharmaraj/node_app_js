var convert = require('./convert'),
    func = convert('intersection', require('../intersection'));

func.placeholder = require('./placeholder');
module.exports = func;
