var convert = require('./convert'),
    func = convert('get', require('../get'));

func.placeholder = require('./placeholder');
module.exports = func;
