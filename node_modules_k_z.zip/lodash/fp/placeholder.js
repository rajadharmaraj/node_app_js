/**
 * The default argument placeholder value for methods.
 *
 * @type {Object}
 */
module.exports = {};
