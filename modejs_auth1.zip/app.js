// app.js

const express = require('express')
const app = express()

// Handle register route with Lambda function 
app.post('/register', async (req, res) => {
  const response = await invokeRegisterLambda(req.body)
  res.send(response)  
})

// Handle login route with Lambda function
app.post('/login', async (req, res) => {
  const response = await invokeLoginLambda(req.body)
  res.send(response)
})

// Lambda functions

const { invoke } = require('aws-lambda')

async function invokeRegisterLambda(userData) {
  const payload = {
    userData  
  }

  const result = await invoke({
    FunctionName: 'registerUser', 
    Payload: JSON.stringify(payload)
  })

  return result.Payload
}

async function invokeLoginLambda(loginData) {
  const payload = {
    loginData
  }
  
  const result = await invoke({
    FunctionName: 'loginUser',
    Payload: JSON.stringify(payload) 
  })

  return result.Payload
}

// registerUser Lambda function

exports.handler = async (event) => {
  // Register user logic
  const userData = event.userData
  
  // Return response
  return registerResponse 
}

// loginUser Lambda function

exports.handler = async (event) => { 
  // Login user logic
  const loginData = event.loginData

  // Return response
  return loginResponse
}