import { Buffer } from 'node:buffer';

export async function handler(event) {

  // Check request
  if(!event.Records) {
    return {
      statusCode: 500,
      body: 'Invalid event'
    };
  }

  const request = event.Records[0]?.cf?.request;  

  if(!request) {
    return {
      statusCode: 400,
      body: 'No request found'
    };
  }


  // Config
  const authUser = 'myusername';
  const authPass = 'mypassword';

  // Construct Auth Header
  const authString = `Basic ${Buffer.from(`${authUser}:${authPass}`).toString('base64')}`;  

  // Get headers
  const headers = request?.headers;

  // Check Authorization 
  if(!headers?.authorization || !headers.authorization[0]?.value || headers.authorization[0].value !== authString) {
    return {
      statusCode: 401,
      body: 'Unauthorized',
      headers: {
        'WWW-Authenticate': [{key: 'WWW-Authenticate', value: 'Basic'}]
      }
    };
  }

  // If authorized, return request
  return request;  

}