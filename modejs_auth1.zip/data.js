// data.js

const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports = {

  async getUsers() {
    const params = {
      TableName: 'users'
    }
    const data = await dynamoDb.scan(params).promise()
    return data.Items
  },

  async addUser(user) {
    const params = {
      TableName: 'users',
      Item: user
    }
    await dynamodb.put(params).promise()
  },

  async updateUser(user) {
    const params = {
      TableName: 'users',
      Key: {
        id: user.id
      },
      UpdateExpression: 'set #username = :username, #email = :email',
      ExpressionAttributeNames: {
        '#username' : 'username',
        '#email' : 'email'
      },
      ExpressionAttributeValues: {
        ':username': user.username,
        ':email': user.email
      }
    }
    await dynamoDb.update(params).promise()
  }

}