// Imports
import aws from 'aws-sdk';
import bcrypt from 'bcryptjs';

// Configure AWS
const dynamodb = new aws.DynamoDB();
const docClient = new aws.DynamoDB.DocumentClient();

// Handler function 
export const handler = async (event) => {

  // Get request type
  const { resource, httpMethod } = event;

  if (resource === '/register' && httpMethod === 'POST') {
    return await register(event); 
  } else if (resource === '/login' && httpMethod === 'POST') {
    return await login(event);
  } else {
    return {
      statusCode: 400,
      body: JSON.stringify({error: 'Not found'})
    }
  }

}

// Register user function

export async function register(event) {

  // Get parameters from event body
  const body = JSON.parse(event.body);
  const { username, password } = body;

  // Hash the password 
  const hashedPwd = await bcrypt.hash(password, 10);

  // Save user to DynamoDB
  const params = {
    TableName: 'Users',
    Item: {
      'PK': username,
      'SK': 'USER',
      'username': username,
      'password': hashedPwd 
    }
  };

  try {
    await docClient.put(params).promise();
    return { status: true };

  } catch (err) {
    return { status: false };
  }

}

// Login user function
  export async function login(event) {

  // Get parameters  
  const { username, password } = JSON.parse(event.body);
  
  // Fetch user from database
  const result = await docClient.get({
      TableName : "Users",
      Key: {
        PK : username,
        SK : "USER"
      }
  }).promise();

  // Validate password 
  const valid = await bcrypt.compare(password, result.Item.password);

  if (!valid) {
    throw 'Invalid login credentials';
  }

  return {
    token: 'TEMP_TOKEN' // Return JWT token 
  };

}